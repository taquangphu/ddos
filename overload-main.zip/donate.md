# Thank you!

## PayPal
https://paypal.me/goncalopolido

## BTC
`bc1qhsdvfaee48qpauxzyccyjjxd7laggmlvyzketh`

## ETH
`0xA438762F645A4DcE1a4c7be66D0E787B8cDb30bd`
